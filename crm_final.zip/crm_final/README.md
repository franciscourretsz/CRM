# CRM

CRM visual de prospección conectado a Supabase y preparado para GitHub Pages.

## Archivos
- `index.html`
- `styles.css`
- `app.js`

## Configuración Supabase
Ejecutar este SQL en Supabase > SQL Editor:

```sql
create table if not exists leads (
  id uuid primary key default gen_random_uuid(),
  created_at timestamp with time zone default now(),
  contact_date date,
  name text not null,
  country text check (country in ('Francia', 'Bélgica', 'Suiza')),
  location text,
  contact_channel text check (contact_channel in ('Email', 'WhatsApp', 'LinkedIn', 'Formulario web')),
  status text,
  priority text,
  response boolean default false,
  followup_done boolean default false,
  followup_date date,
  meeting_done boolean default false,
  meeting_status text,
  next_action text,
  notes text,
  history text
);

alter table leads enable row level security;

drop policy if exists "Public read leads" on leads;
drop policy if exists "Public insert leads" on leads;
drop policy if exists "Public update leads" on leads;
drop policy if exists "Public delete leads" on leads;

create policy "Public read leads" on leads for select using (true);
create policy "Public insert leads" on leads for insert with check (true);
create policy "Public update leads" on leads for update using (true) with check (true);
create policy "Public delete leads" on leads for delete using (true);
```

## GitHub Pages
Subir los 3 archivos a la raíz del repo y activar Pages desde Settings > Pages > Deploy from branch > main > /root.
