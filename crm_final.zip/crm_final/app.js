const SUPABASE_URL = 'https://qymfcrginsxemxmyujvr.supabase.co';
const SUPABASE_ANON_KEY = 'sb_publishable_iXUK6jm_JshRc_fOixTSpA_gWzlRrRX';
const supabaseClient = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

const COUNTRIES = ['Francia','Bélgica','Suiza'];
const CHANNELS = ['Email','WhatsApp','LinkedIn','Formulario web'];
const STATUSES = ['Nuevo','Contactado','Respondió','Interesado','Reunión agendada','Reunión hecha','Propuesta enviada','Ganado','Perdido','Relanzar'];
const MEETING_STATUSES = ['Sin reunión','Agendada','Realizada','No asistió','Reprogramar','Ganada','Perdida'];
let leads = [];
let filtered = [];

const $ = (id) => document.getElementById(id);
const today = () => new Date().toISOString().slice(0,10);

function fillSelect(el, options, allLabel=null){
  el.innerHTML = '';
  if(allLabel){ const o=document.createElement('option'); o.value='all'; o.textContent=allLabel; el.appendChild(o); }
  options.forEach(v=>{ const o=document.createElement('option'); o.value=v; o.textContent=v; el.appendChild(o); });
}
function boolText(v){return v ? 'Sí':'No'}
function toast(msg){ $('toast').textContent=msg; $('toast').classList.remove('hidden'); setTimeout(()=>$('toast').classList.add('hidden'), 2600); }
function normalizeBool(v){ if(typeof v==='boolean')return v; const s=String(v||'').toLowerCase().trim(); return ['si','sí','true','1','yes','x'].includes(s); }
function parseDate(v){ if(!v) return null; const d=String(v).trim(); if(/^\d{4}-\d{2}-\d{2}$/.test(d)) return d; const m=d.match(/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{2,4})$/); if(m){ const yyyy=m[3].length===2?`20${m[3]}`:m[3]; return `${yyyy}-${m[2].padStart(2,'0')}-${m[1].padStart(2,'0')}`; } return null; }
function isDue(l){ return l.followup_date && !l.followup_done && l.followup_date <= today(); }

async function loadLeads(){
  const { data, error } = await supabaseClient.from('leads').select('*').order('contact_date',{ascending:false}).order('created_at',{ascending:false});
  if(error){ toast('Error cargando datos: ' + error.message); return; }
  leads = data || [];
  applyFilters();
}
function applyFilters(){
  const q=$('searchInput').value.toLowerCase().trim();
  const country=$('countryFilter').value, status=$('statusFilter').value, channel=$('channelFilter').value;
  const response=$('responseFilter').value, meeting=$('meetingFilter').value, followup=$('followupFilter').value;
  filtered = leads.filter(l=>{
    const txt=[l.name,l.country,l.location,l.contact_channel,l.status,l.priority,l.meeting_status,l.next_action,l.notes,l.history].join(' ').toLowerCase();
    if(q && !txt.includes(q)) return false;
    if(country!=='all' && l.country!==country) return false;
    if(status!=='all' && l.status!==status) return false;
    if(channel!=='all' && l.contact_channel!==channel) return false;
    if(response!=='all' && String(!!l.response)!==response) return false;
    if(meeting!=='all' && String(!!l.meeting_done)!==meeting) return false;
    if(followup==='due' && !isDue(l)) return false;
    if(followup==='pending' && !(l.followup_date && !l.followup_done && l.followup_date > today())) return false;
    if(followup==='done' && !l.followup_done) return false;
    return true;
  });
  render();
}
function renderStats(){
  const total=leads.length, responses=leads.filter(l=>l.response).length, meetings=leads.filter(l=>l.meeting_done).length, due=leads.filter(isDue).length;
  $('statTotal').textContent=total; $('statResponses').textContent=responses; $('statMeetings').textContent=meetings; $('statDue').textContent=due;
  $('statResponseRate').textContent= total? Math.round(responses/total*100)+'%' : '0%';
  $('statMeetingRate').textContent= total? Math.round(meetings/total*100)+'%' : '0%';
}
function renderDue(){
  const due=leads.filter(isDue).sort((a,b)=>String(a.followup_date).localeCompare(String(b.followup_date)));
  $('dueCounter').textContent=`${due.length} pendientes`;
  $('dueList').innerHTML = due.slice(0,6).map(l=>`<div class="due-item"><strong>${escapeHtml(l.name)}</strong><p>${l.followup_date} · ${escapeHtml(l.country||'')} · ${escapeHtml(l.contact_channel||'')}</p><p>${escapeHtml(l.next_action||l.notes||'Sin próxima acción')}</p></div>`).join('') || '<p class="notes">No hay relanzamientos vencidos para hoy.</p>';
}
function badge(value, cls=''){ return `<span class="badge ${cls}">${value}</span>`; }
function renderCards(){
  $('cardsView').innerHTML = filtered.map(l=>`
    <article class="card">
      <div class="card-head"><div><h3>${escapeHtml(l.name)}</h3><div>${badge(escapeHtml(l.status||'Nuevo'))} ${badge(escapeHtml(l.priority||'Media'))}</div></div>${isDue(l)?badge('Relanzar hoy','warn'):''}</div>
      <div class="meta">
        <div><span>Fecha</span>${l.contact_date||'-'}</div><div><span>País</span>${escapeHtml(l.country||'-')}</div>
        <div><span>Ubicación</span>${escapeHtml(l.location||'-')}</div><div><span>Vía</span>${escapeHtml(l.contact_channel||'-')}</div>
        <div><span>Respuesta</span>${badge(boolText(l.response),l.response?'ok':'')}</div><div><span>Reunión</span>${badge(boolText(l.meeting_done),l.meeting_done?'ok':'')}</div>
        <div><span>Relanzamiento</span>${l.followup_date||'-'}</div><div><span>Estado reunión</span>${escapeHtml(l.meeting_status||'-')}</div>
      </div>
      <p class="notes">${escapeHtml(l.notes||'Sin notas')}</p>
      <div class="card-actions"><button class="btn secondary" onclick="editLead('${l.id}')">Editar</button></div>
    </article>`).join('') || '<p class="notes">No hay leads con estos filtros.</p>';
}
function renderTable(){
  $('tableBody').innerHTML = filtered.map(l=>`<tr><td>${l.contact_date||''}</td><td>${escapeHtml(l.name)}</td><td>${escapeHtml(l.country||'')}</td><td>${escapeHtml(l.location||'')}</td><td>${escapeHtml(l.contact_channel||'')}</td><td>${boolText(l.response)}</td><td>${l.followup_date||''}</td><td>${boolText(l.meeting_done)}</td><td>${escapeHtml(l.status||'')}</td><td>${escapeHtml(l.priority||'')}</td><td><button class="btn secondary" onclick="editLead('${l.id}')">Editar</button></td></tr>`).join('');
}
function render(){
  renderStats(); renderDue(); renderCards(); renderTable();
  $('resultCount').textContent = `${filtered.length} resultados`;
  const mode=$('viewMode').value;
  $('cardsView').classList.toggle('hidden',mode!=='cards');
  $('tableView').classList.toggle('hidden',mode!=='table');
}
function escapeHtml(str){ return String(str??'').replace(/[&<>'"]/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c])); }

function openNew(){
  $('modalTitle').textContent='Nuevo lead'; $('leadForm').reset(); $('leadId').value=''; $('contactDate').value=today(); $('deleteLeadBtn').classList.add('hidden'); $('leadDialog').showModal();
}
window.editLead = (id)=>{
  const l=leads.find(x=>x.id===id); if(!l) return;
  $('modalTitle').textContent='Editar lead'; $('leadId').value=l.id; $('contactDate').value=l.contact_date||''; $('name').value=l.name||''; $('country').value=l.country||'Francia'; $('location').value=l.location||''; $('contactChannel').value=l.contact_channel||'Email'; $('status').value=l.status||'Nuevo'; $('priority').value=l.priority||'Media'; $('response').value=String(!!l.response); $('followupDone').value=String(!!l.followup_done); $('followupDate').value=l.followup_date||''; $('meetingDone').value=String(!!l.meeting_done); $('meetingStatus').value=l.meeting_status||'Sin reunión'; $('nextAction').value=l.next_action||''; $('notes').value=l.notes||''; $('historyText').value=l.history||''; $('deleteLeadBtn').classList.remove('hidden'); $('leadDialog').showModal();
}
function getFormData(){ return {contact_date:$('contactDate').value||today(), name:$('name').value.trim(), country:$('country').value, location:$('location').value.trim(), contact_channel:$('contactChannel').value, status:$('status').value, priority:$('priority').value, response:$('response').value==='true', followup_done:$('followupDone').value==='true', followup_date:$('followupDate').value||null, meeting_done:$('meetingDone').value==='true', meeting_status:$('meetingStatus').value, next_action:$('nextAction').value.trim(), notes:$('notes').value.trim(), history:$('historyText').value.trim()}; }
async function saveLead(e){
  e.preventDefault(); const payload=getFormData(); if(!payload.name){toast('El nombre es obligatorio'); return;}
  const id=$('leadId').value; const res = id ? await supabaseClient.from('leads').update(payload).eq('id',id) : await supabaseClient.from('leads').insert(payload);
  if(res.error){ toast('Error guardando: '+res.error.message); return; }
  $('leadDialog').close(); toast('Lead guardado'); await loadLeads();
}
async function deleteLead(){
  const id=$('leadId').value; if(!id || !confirm('¿Eliminar este lead?')) return;
  const {error}=await supabaseClient.from('leads').delete().eq('id',id); if(error){toast('Error eliminando: '+error.message); return;}
  $('leadDialog').close(); toast('Lead eliminado'); await loadLeads();
}
function exportCsv(){
  const rows=filtered.map(l=>({fecha:l.contact_date,nombre:l.name,pais:l.country,ubicacion:l.location,via:l.contact_channel,estado:l.status,prioridad:l.priority,respuesta:boolText(l.response),hubo_relanzamiento:boolText(l.followup_done),fecha_relanzamiento:l.followup_date,reunion:boolText(l.meeting_done),estado_reunion:l.meeting_status,proxima_accion:l.next_action,notas:l.notes,historial:l.history}));
  const csv=Papa.unparse(rows); const blob=new Blob([csv],{type:'text/csv;charset=utf-8;'}); const url=URL.createObjectURL(blob); const a=document.createElement('a'); a.href=url; a.download=`crm_export_${today()}.csv`; a.click(); URL.revokeObjectURL(url);
}
async function importCsv(){
  const file=$('csvFile').files[0]; if(!file){toast('Elegí un archivo CSV'); return;}
  Papa.parse(file,{header:true,skipEmptyLines:true,complete:async ({data})=>{
    const payload=data.map(r=>{
      const get=(...keys)=>{ for(const k of keys){ const found=Object.keys(r).find(x=>x.toLowerCase().trim()===k); if(found) return r[found]; } return ''; };
      const countryRaw=get('pais','país','country')||'Francia';
      const country=COUNTRIES.find(c=>countryRaw.toLowerCase().includes(c.toLowerCase().slice(0,5)))||'Francia';
      const channelRaw=get('via','vía','via de contacto','vía de contacto','contact_channel','canal')||'Email';
      const channel=CHANNELS.find(c=>channelRaw.toLowerCase().includes(c.toLowerCase().split(' ')[0]))||'Email';
      return { contact_date:parseDate(get('fecha','fecha de contacto','contact_date'))||today(), name:get('nombre','name').trim(), country, location:get('ubicacion','ubicación','location'), contact_channel:channel, status:get('estado','status')||'Nuevo', priority:get('prioridad','priority')||'Media', response:normalizeBool(get('respuesta','respondio','respondió','response')), followup_done:normalizeBool(get('hubo relanzamiento','relanzamiento','followup_done')), followup_date:parseDate(get('fecha relanzamiento','fecha de relanzamiento','followup_date')), meeting_done:normalizeBool(get('reunion','reunión','meeting_done')), meeting_status:get('estado reunion','estado reunión','meeting_status')||'Sin reunión', next_action:get('proxima accion','próxima acción','next_action'), notes:get('notas','notes'), history:get('historial','history') };
    }).filter(x=>x.name);
    if(!payload.length){toast('No encontré filas válidas con nombre'); return;}
    const {error}=await supabaseClient.from('leads').insert(payload); if(error){toast('Error importando: '+error.message); return;}
    $('importDialog').close(); toast(`${payload.length} leads importados`); await loadLeads();
  }});
}
function init(){
  fillSelect($('country'),COUNTRIES); fillSelect($('countryFilter'),COUNTRIES,'Todos'); fillSelect($('contactChannel'),CHANNELS); fillSelect($('channelFilter'),CHANNELS,'Todas'); fillSelect($('status'),STATUSES); fillSelect($('statusFilter'),STATUSES,'Todos'); fillSelect($('meetingStatus'),MEETING_STATUSES);
  $('openLeadBtn').onclick=openNew; $('refreshBtn').onclick=loadLeads; $('exportBtn').onclick=exportCsv; $('openImportBtn').onclick=()=>$('importDialog').showModal(); $('closeLeadBtn').onclick=()=>$('leadDialog').close(); $('cancelLeadBtn').onclick=()=>$('leadDialog').close(); $('closeImportBtn').onclick=()=>$('importDialog').close(); $('cancelImportBtn').onclick=()=>$('importDialog').close(); $('leadForm').addEventListener('submit',saveLead); $('deleteLeadBtn').onclick=deleteLead; $('importBtn').onclick=importCsv;
  ['searchInput','countryFilter','statusFilter','channelFilter','responseFilter','meetingFilter','followupFilter','viewMode'].forEach(id=>$(id).addEventListener('input',applyFilters));
  loadLeads();
}
init();
